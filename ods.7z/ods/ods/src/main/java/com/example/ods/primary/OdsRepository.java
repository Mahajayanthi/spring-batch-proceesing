package com.example.ods.primary;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OdsRepository extends JpaRepository<Ods,Integer> {

}
