package com.example.ods.secondary;

import org.springframework.data.jpa.repository.JpaRepository;

public interface City_stopRepository extends JpaRepository<City_stop,Integer> {

}
