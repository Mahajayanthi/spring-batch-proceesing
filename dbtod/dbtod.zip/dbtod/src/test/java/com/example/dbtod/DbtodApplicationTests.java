package com.example.dbtod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbtodApplicationTests {

	@Test
	void contextLoads() {
	}

}
